import '../core/api_client.dart';
import '../core/session_store.dart';

class AuthService {
  final _dio = ApiClient.instance.dio;

  Future<AppSession> register({
    required String name,
    String? email,
    String? mobile,
    required String password,
    required bool termsAccepted,
  }) async {
    final res = await _dio.post('/auth/register', data: {
      'name': name,
      'email': email ?? '',
      'mobile': mobile ?? '',
      'password': password,
      'termsAccepted': termsAccepted,
    });
    final data = res.data as Map<String, dynamic>;
    final user = data['user'] as Map<String, dynamic>;
    final session = AppSession(token: data['token'] as String, userId: user['id'] as int, name: user['name'] as String, purpose: user['purpose'] as String?);
    await SessionStore.instance.save(session);
    return session;
  }

  Future<AppSession> login({required String identifier, required String password}) async {
    final res = await _dio.post('/auth/login', data: {'identifier': identifier, 'password': password});
    final data = res.data as Map<String, dynamic>;
    final user = data['user'] as Map<String, dynamic>;
    final session = AppSession(token: data['token'] as String, userId: user['id'] as int, name: user['name'] as String, purpose: user['purpose'] as String?);
    await SessionStore.instance.save(session);
    return session;
  }

  Future<void> setPurpose(String purpose) async {
    final res = await _dio.patch('/auth/purpose', data: {'purpose': purpose});
    final user = (res.data as Map<String, dynamic>)['user'] as Map<String, dynamic>;
    final old = await SessionStore.instance.read();
    if (old != null) {
      await SessionStore.instance.save(AppSession(token: old.token, userId: old.userId, name: old.name, purpose: user['purpose'] as String?));
    }
  }

  Future<void> deleteAccount() async {
    await _dio.delete('/auth/delete-account');
    await SessionStore.instance.clear();
  }
}
