import '../core/api_client.dart';
import '../core/models.dart';

class ChatServiceApi {
  final _dio = ApiClient.instance.dio;

  Future<List<ChatMessage>> messages(int providerId) async {
    final res = await _dio.get('/chat/$providerId');
    return ((res.data['data'] as List?) ?? []).map((e) => ChatMessage.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<void> send(int providerId, String text) async {
    await _dio.post('/chat/$providerId', data: {'text': text});
  }
}
