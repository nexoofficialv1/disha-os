import 'package:flutter/material.dart';

import '../core/api_client.dart';
import '../core/session_store.dart';
import '../services/auth_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  AppSession? _session;
  String? _error;

  @override
  void initState() {
    super.initState();
    SessionStore.instance.read().then((s) => setState(() => _session = s));
  }

  Future<void> _deleteAccount() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Account'),
        content: const Text('আপনার account deactivate হবে। Continue করবেন?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await AuthService().deleteAccount();
      if (mounted) Navigator.pushNamedAndRemoveUntil(context, '/login', (_) => false);
    } catch (e) {
      setState(() => _error = apiError(e));
    }
  }

  Future<void> _logout() async {
    await SessionStore.instance.clear();
    if (mounted) Navigator.pushNamedAndRemoveUntil(context, '/login', (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile & Settings')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          CircleAvatar(radius: 42, child: Text((_session?.name ?? 'D').substring(0, 1).toUpperCase(), style: const TextStyle(fontSize: 30))),
          const SizedBox(height: 10),
          Center(child: Text(_session?.name ?? 'DISHA User', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
          if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
          const SizedBox(height: 24),
          ListTile(leading: const Icon(Icons.business), title: const Text('Provider Profile'), onTap: () => Navigator.pushNamed(context, '/provider-setup')),
          ListTile(leading: const Icon(Icons.event_note), title: const Text('My Bookings'), onTap: () => Navigator.pushNamed(context, '/bookings')),
          ListTile(leading: const Icon(Icons.privacy_tip), title: const Text('Privacy Policy'), onTap: () => Navigator.pushNamed(context, '/privacy')),
          ListTile(leading: const Icon(Icons.article), title: const Text('Terms & Conditions'), onTap: () => Navigator.pushNamed(context, '/terms')),
          ListTile(leading: const Icon(Icons.delete_forever), title: const Text('Delete Account'), onTap: _deleteAccount),
          ListTile(leading: const Icon(Icons.logout), title: const Text('Logout'), onTap: _logout),
          const SizedBox(height: 20),
          const Center(child: Text('Powered by ASTRA Technologies')),
          const Center(child: Text('Copyright © Astra Technologies. All Rights Reserved.')),
        ],
      ),
    );
  }
}
