import 'package:flutter/material.dart';

import '../core/api_client.dart';
import '../core/models.dart';
import '../services/chat_service.dart';

class ChatScreenArgs {
  ChatScreenArgs({required this.providerId, required this.providerName});
  final int providerId;
  final String providerName;
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.args});
  final ChatScreenArgs args;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _api = ChatServiceApi();
  final _text = TextEditingController();
  List<ChatMessage> _messages = [];
  bool _loading = true;
  bool _sending = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final data = await _api.messages(widget.args.providerId);
      setState(() => _messages = data);
    } catch (e) {
      setState(() => _error = apiError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _send() async {
    final msg = _text.text.trim();
    if (msg.isEmpty) return;
    setState(() => _sending = true);
    try {
      await _api.send(widget.args.providerId, msg);
      _text.clear();
      await _load();
    } catch (e) {
      setState(() => _error = apiError(e));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.args.providerName)),
      body: Column(children: [
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
                  ? Center(child: Text(_error!))
                  : _messages.isEmpty
                      ? const Center(child: Text('No messages yet'))
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: _messages.length,
                          itemBuilder: (context, i) {
                            final m = _messages[i];
                            return Card(child: ListTile(title: Text(m.text), subtitle: Text(m.senderName)));
                          },
                        ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(child: TextField(controller: _text, decoration: const InputDecoration(hintText: 'Message'))),
              IconButton(onPressed: _sending ? null : _send, icon: const Icon(Icons.send)),
            ]),
          ),
        ),
      ]),
    );
  }
}
