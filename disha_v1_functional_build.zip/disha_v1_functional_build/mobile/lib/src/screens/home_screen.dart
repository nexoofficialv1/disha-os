import 'dart:async';

import 'package:flutter/material.dart';

import '../core/api_client.dart';
import '../core/models.dart';
import '../services/provider_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _api = ProviderServiceApi();
  final _search = TextEditingController();
  List<Category> _categories = [];
  List<ProviderItem> _providers = [];
  int? _categoryId;
  bool _loading = true;
  String? _error;
  late Timer _timer;
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => setState(() => _now = DateTime.now()));
  }

  @override
  void dispose() {
    _timer.cancel();
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final cats = await _api.categories();
      final providers = await _api.providers(q: _search.text.trim(), categoryId: _categoryId);
      setState(() { _categories = cats; _providers = providers; });
    } catch (e) {
      setState(() => _error = apiError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final timeText = '${_now.hour.toString().padLeft(2, '0')}:${_now.minute.toString().padLeft(2, '0')}';
    return Scaffold(
      appBar: AppBar(
        title: const Text('DISHA'),
        actions: [
          IconButton(onPressed: () => Navigator.pushNamed(context, '/bookings'), icon: const Icon(Icons.event_note)),
          IconButton(onPressed: () => Navigator.pushNamed(context, '/settings'), icon: const Icon(Icons.person)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.pushNamed(context, '/provider-setup'),
        icon: const Icon(Icons.add_business),
        label: const Text('Provider'),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), gradient: const LinearGradient(colors: [Color(0xFF073B7A), Color(0xFF0B5CA8)])),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('📍 Kalna · Purba Bardhaman', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 10),
                Text(timeText, style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900)),
                const Text('Nearby local services', style: TextStyle(color: Colors.white70)),
              ]),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _search,
              decoration: InputDecoration(hintText: 'কী পরিষেবা দরকার?', prefixIcon: const Icon(Icons.search), suffixIcon: IconButton(onPressed: _load, icon: const Icon(Icons.arrow_forward))),
              onSubmitted: (_) => _load(),
            ),
            const SizedBox(height: 14),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(label: const Text('All'), selected: _categoryId == null, onSelected: (_) { setState(() => _categoryId = null); _load(); }),
                ),
                ..._categories.map((c) => Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(label: Text('${c.icon ?? ''} ${c.nameBn}'), selected: _categoryId == c.id, onSelected: (_) { setState(() => _categoryId = c.id); _load(); }),
                )),
              ]),
            ),
            const SizedBox(height: 18),
            const Text('Available Providers', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            if (_loading) const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator()))
            else if (_error != null) _StateCard(icon: Icons.wifi_off, title: 'Server connection problem', text: _error!, action: _load)
            else if (_providers.isEmpty) const _StateCard(icon: Icons.search_off, title: 'এখন কোনো provider available নেই', text: 'Provider add হলে এখানে দেখা যাবে।')
            else ..._providers.map((p) => _ProviderCard(provider: p)),
          ],
        ),
      ),
    );
  }
}

class _ProviderCard extends StatelessWidget {
  const _ProviderCard({required this.provider});
  final ProviderItem provider;

  @override
  Widget build(BuildContext context) {
    final first = provider.services.isEmpty ? 'Service' : provider.services.first.title;
    final price = provider.services.isEmpty ? '' : (provider.services.first.price ?? '');
    return Card(
      child: ListTile(
        leading: CircleAvatar(child: Text(provider.services.isEmpty ? 'D' : (provider.services.first.category?.icon ?? 'D'))),
        title: Text(provider.displayName, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text('$first ${price.isEmpty ? '' : '· $price'}\n${provider.area}, ${provider.city}'),
        isThreeLine: true,
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.pushNamed(context, '/provider-detail', arguments: provider.id),
      ),
    );
  }
}

class _StateCard extends StatelessWidget {
  const _StateCard({required this.icon, required this.title, required this.text, this.action});
  final IconData icon;
  final String title;
  final String text;
  final VoidCallback? action;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          Icon(icon, size: 42),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
          Text(text, textAlign: TextAlign.center),
          if (action != null) TextButton(onPressed: action, child: const Text('Retry')),
        ]),
      ),
    );
  }
}
