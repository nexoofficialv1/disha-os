import 'package:flutter/material.dart';

enum LegalKind { privacy, terms }

class LegalScreen extends StatelessWidget {
  const LegalScreen({super.key, required this.kind});
  final LegalKind kind;

  @override
  Widget build(BuildContext context) {
    final isPrivacy = kind == LegalKind.privacy;
    return Scaffold(
      appBar: AppBar(title: Text(isPrivacy ? 'Privacy Policy' : 'Terms & Conditions')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(isPrivacy ? 'Privacy Policy' : 'Terms & Conditions', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          if (isPrivacy) ...const [
            Text('DISHA collects user profile, contact, provider listing, booking and chat data only to provide local service discovery and booking features.'),
            SizedBox(height: 10),
            Text('Location, notification, camera or file permissions will be requested only when needed for the relevant function.'),
            SizedBox(height: 10),
            Text('Before public Play Store release, this text must be finalized and hosted on the official DISHA domain.'),
          ] else ...const [
            Text('Users and providers must provide accurate information and must not misuse DISHA for fraud, spam, illegal services or harassment.'),
            SizedBox(height: 10),
            Text('Official service integrations will be used only through authorized APIs or official portal redirects.'),
          ],
          const SizedBox(height: 30),
          const Text('Copyright © Astra Technologies. All Rights Reserved.'),
        ],
      ),
    );
  }
}
