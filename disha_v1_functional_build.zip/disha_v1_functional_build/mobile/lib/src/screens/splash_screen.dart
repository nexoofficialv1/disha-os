import 'package:flutter/material.dart';

import '../../main.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _go();
  }

  Future<void> _go() async {
    await Future.delayed(const Duration(milliseconds: 700));
    final route = await initialRoute();
    if (mounted) Navigator.pushReplacementNamed(context, route);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xFF062F63), Color(0xFF0B5CA8)]),
        ),
        child: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircleAvatar(radius: 48, backgroundColor: Colors.white, child: Text('D', style: TextStyle(fontSize: 54, fontWeight: FontWeight.w900, color: Color(0xFF0B5CA8)))),
              SizedBox(height: 18),
              Text('DISHA', style: TextStyle(color: Colors.white, fontSize: 44, fontWeight: FontWeight.w900)),
              Text('Local Services OS', style: TextStyle(color: Colors.white70)),
              SizedBox(height: 8),
              Text('Powered by ASTRA Technologies', style: TextStyle(color: Colors.white60, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}
