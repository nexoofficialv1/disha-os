import 'package:flutter/material.dart';

import '../core/api_client.dart';
import '../services/auth_service.dart';

class PurposeScreen extends StatefulWidget {
  const PurposeScreen({super.key});

  @override
  State<PurposeScreen> createState() => _PurposeScreenState();
}

class _PurposeScreenState extends State<PurposeScreen> {
  bool _loading = false;
  String? _error;

  Future<void> _choose(String purpose, String route) async {
    setState(() { _loading = true; _error = null; });
    try {
      await AuthService().setPurpose(purpose);
      if (mounted) Navigator.pushReplacementNamed(context, route);
    } catch (e) {
      setState(() => _error = apiError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Widget _card(String icon, String title, String sub, String purpose, String route) {
    return Card(
      child: ListTile(
        enabled: !_loading,
        leading: Text(icon, style: const TextStyle(fontSize: 32)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(sub),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _choose(purpose, route),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('আপনি কী করতে চান?')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
          _card('🔍', 'পরিষেবা নিতে চাই', 'Service খুঁজব, chat করব, booking করব', 'TAKER', '/home'),
          _card('🛠️', 'পরিষেবা দিতে চাই', 'নিজের provider profile তৈরি করব', 'PROVIDER', '/provider-setup'),
          _card('🔁', 'দুটোই', 'একই account থেকে দুইভাবে ব্যবহার করব', 'BOTH', '/home'),
        ],
      ),
    );
  }
}
