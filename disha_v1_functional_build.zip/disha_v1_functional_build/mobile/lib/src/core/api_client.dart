import 'package:dio/dio.dart';

import 'app_config.dart';
import 'session_store.dart';

class ApiClient {
  ApiClient._() {
    dio = Dio(BaseOptions(
      baseUrl: AppConfig.apiBaseUrl,
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 15),
      headers: {'Content-Type': 'application/json'},
    ));

    dio.interceptors.add(InterceptorsWrapper(onRequest: (options, handler) async {
      final session = await SessionStore.instance.read();
      if (session?.token != null) options.headers['Authorization'] = 'Bearer ${session!.token}';
      handler.next(options);
    }));
  }

  static final instance = ApiClient._();
  late final Dio dio;
}

String apiError(Object e) {
  if (e is DioException) {
    final data = e.response?.data;
    if (data is Map && data['error'] != null) return data['error'].toString();
    if (e.type == DioExceptionType.connectionTimeout) return 'Connection timeout';
    if (e.type == DioExceptionType.connectionError) return 'Server connection failed';
  }
  return 'Something went wrong';
}
