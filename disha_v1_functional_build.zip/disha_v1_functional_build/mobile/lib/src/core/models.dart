class Category {
  Category({required this.id, required this.name, required this.nameBn, this.icon});
  final int id;
  final String name;
  final String nameBn;
  final String? icon;
  factory Category.fromJson(Map<String, dynamic> json) => Category(
        id: json['id'] as int,
        name: json['name'] as String,
        nameBn: json['nameBn'] as String,
        icon: json['icon'] as String?,
      );
}

class ProviderService {
  ProviderService({required this.id, required this.title, this.price, this.description, this.category});
  final int id;
  final String title;
  final String? price;
  final String? description;
  final Category? category;
  factory ProviderService.fromJson(Map<String, dynamic> json) => ProviderService(
        id: json['id'] as int,
        title: json['title'] as String,
        price: json['price'] as String?,
        description: json['description'] as String?,
        category: json['category'] == null ? null : Category.fromJson(json['category'] as Map<String, dynamic>),
      );
}

class ProviderItem {
  ProviderItem({
    required this.id,
    required this.displayName,
    required this.area,
    required this.city,
    required this.mobile,
    this.whatsapp,
    this.availableTime,
    required this.verified,
    required this.services,
  });

  final int id;
  final String displayName;
  final String area;
  final String city;
  final String mobile;
  final String? whatsapp;
  final String? availableTime;
  final bool verified;
  final List<ProviderService> services;

  factory ProviderItem.fromJson(Map<String, dynamic> json) => ProviderItem(
        id: json['id'] as int,
        displayName: json['displayName'] as String,
        area: json['area'] as String,
        city: json['city'] as String,
        mobile: json['mobile'] as String,
        whatsapp: json['whatsapp'] as String?,
        availableTime: json['availableTime'] as String?,
        verified: json['verified'] as bool? ?? false,
        services: ((json['services'] as List?) ?? []).map((e) => ProviderService.fromJson(e as Map<String, dynamic>)).toList(),
      );
}

class BookingItem {
  BookingItem({required this.id, required this.serviceName, required this.status, required this.date});
  final int id;
  final String serviceName;
  final String status;
  final DateTime date;
  factory BookingItem.fromJson(Map<String, dynamic> json) => BookingItem(
        id: json['id'] as int,
        serviceName: json['serviceName'] as String,
        status: json['status'] as String,
        date: DateTime.parse(json['date'] as String),
      );
}

class ChatMessage {
  ChatMessage({required this.id, required this.text, required this.createdAt, required this.senderName});
  final int id;
  final String text;
  final DateTime createdAt;
  final String senderName;
  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
        id: json['id'] as int,
        text: json['text'] as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
        senderName: ((json['sender'] as Map?)?['name'] ?? 'User').toString(),
      );
}
