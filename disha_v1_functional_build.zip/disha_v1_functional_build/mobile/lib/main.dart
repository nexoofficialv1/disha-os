import 'package:flutter/material.dart';

import 'src/core/app_theme.dart';
import 'src/core/session_store.dart';
import 'src/screens/booking_list_screen.dart';
import 'src/screens/chat_screen.dart';
import 'src/screens/home_screen.dart';
import 'src/screens/legal_screen.dart';
import 'src/screens/login_screen.dart';
import 'src/screens/provider_detail_screen.dart';
import 'src/screens/provider_setup_screen.dart';
import 'src/screens/purpose_screen.dart';
import 'src/screens/settings_screen.dart';
import 'src/screens/splash_screen.dart';

void main() {
  runApp(const DishaApp());
}

class DishaApp extends StatelessWidget {
  const DishaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DISHA',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      routes: {
        '/': (_) => const SplashScreen(),
        '/login': (_) => const LoginScreen(),
        '/purpose': (_) => const PurposeScreen(),
        '/home': (_) => const HomeScreen(),
        '/provider-setup': (_) => const ProviderSetupScreen(),
        '/settings': (_) => const SettingsScreen(),
        '/bookings': (_) => const BookingListScreen(),
        '/privacy': (_) => const LegalScreen(kind: LegalKind.privacy),
        '/terms': (_) => const LegalScreen(kind: LegalKind.terms),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/provider-detail') {
          final providerId = settings.arguments as int;
          return MaterialPageRoute(builder: (_) => ProviderDetailScreen(providerId: providerId));
        }
        if (settings.name == '/chat') {
          final args = settings.arguments as ChatScreenArgs;
          return MaterialPageRoute(builder: (_) => ChatScreen(args: args));
        }
        return null;
      },
    );
  }
}

Future<String> initialRoute() async {
  final session = await SessionStore.instance.read();
  if (session == null) return '/login';
  if (session.purpose == null || session.purpose!.isEmpty) return '/purpose';
  return '/home';
}
