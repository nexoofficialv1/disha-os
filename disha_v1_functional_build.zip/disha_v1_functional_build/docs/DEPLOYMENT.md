# DISHA Deployment Notes

## Backend
Recommended first deployment:
- Node.js API: Render/Railway/DigitalOcean/SmarterASP if Node.js is supported
- Database: PostgreSQL managed database
- Public API domain: `https://api.disha.nexoofficial.in/api`

## Mobile API URL
Build with:
```bash
flutter build apk --release --dart-define=API_BASE_URL=https://api.disha.nexoofficial.in/api
```

## GitHub Actions
The workflow generates a debug APK artifact. For Play Store release, add signing keys as GitHub secrets and switch to release build.

## Domain plan
- `nexoofficial.in` stays with NEXO
- `api.disha.nexoofficial.in` for DISHA backend
- `disha.nexoofficial.in` for DISHA landing/legal pages
- `astra.nexoofficial.in` for ASTRA Technologies website
