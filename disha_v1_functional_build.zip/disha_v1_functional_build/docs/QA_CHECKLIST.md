# DISHA v1.0 QA Checklist

## App
- Register screen validates name/contact/password
- Terms checkbox required before account creation
- Login stores token and user state
- Purpose selection saves to backend
- Provider profile create/edit works
- Provider profile prefill works after save
- Service category selection works
- Search refreshes provider list
- Empty provider list shows empty state
- Network error shows error state
- Provider card opens provider details
- Call/WhatsApp/direction buttons use real provider values
- Booking form blocks empty service/date
- Booking creation calls backend
- Chat screen fetches and sends messages
- Settings contains Privacy, Terms, Delete Account
- Delete Account calls backend and logs out
- Back navigation checked on all screens
- Small screen scroll behavior checked

## Backend
- No public route returns sensitive password hash
- `/api/providers/me/profile` is before `/api/providers/:id`
- `/api/chat/summary` is before `/api/chat/:providerId`
- Rate limit enabled
- Helmet enabled
- CORS controlled by env
- JWT required for protected endpoints
- Zod validation enabled
- Booking past-date blocked
- Booking status permission checked
- Provider profile ownership checked
- User soft-delete implemented
- Prisma schema migration ready

## Release gate
Do not create final APK until backend URL, database, legal pages, and privacy policy are configured.
