# DISHA v1.0 Functional Build

**DISHA – Local Services OS**  
An ASTRA Technologies Product.

This package is a functional source-code build for development and testing. It includes a Flutter mobile app, Node.js backend, PostgreSQL schema, and GitHub Actions APK build workflow.

## What works in this build
- Register/login with email or mobile + password
- Terms acceptance before account creation
- Purpose selection: service taker / service provider / both
- Provider profile create/edit with services
- Service category API
- Provider listing and search API
- Provider details screen
- Booking request creation
- Booking status update API
- Basic chat API and app screen
- Settings, Privacy Policy, Terms & Conditions, Delete Account
- Backend validation, route-order fixes, rate limiting, Helmet security headers
- GitHub Actions debug APK build workflow

## What still needs external setup before real public release
- PostgreSQL database URL
- Backend deployment URL
- SMS OTP provider for mobile OTP
- Google Sign-In OAuth credentials
- Maps/weather provider keys
- Final lawyer-reviewed Privacy Policy and Terms

## Recommended repo layout
```text
DISHA/
├── mobile/
├── backend/
├── docs/
└── .github/workflows/build-apk.yml
```

## Quick backend start
```bash
cd backend
cp .env.example .env
npm install
npx prisma generate
npx prisma migrate dev --name init
node prisma/seed.js
npm run dev
```

## Quick mobile start
```bash
cd mobile
flutter create . --platforms=android --org in.nexoofficial.disha
flutter pub get
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:5000/api
```

Copyright © Astra Technologies. All Rights Reserved.
