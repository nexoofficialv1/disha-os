const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const categories = [
    ['Salon', 'সেলুন', '💇'],
    ['Car Rental', 'গাড়ি ভাড়া', '🚕'],
    ['Courier', 'কুরিয়ার', '📦'],
    ['Cyber Cafe', 'সাইবার ক্যাফে', '🖨️'],
    ['Beauty Parlour', 'বিউটি পার্লার', '💄'],
    ['Electrician', 'ইলেকট্রিশিয়ান', '⚡'],
    ['Plumber', 'প্লাম্বার', '🔧'],
    ['Tuition', 'টিউশন', '📚'],
    ['Driver', 'ড্রাইভার', '🚗'],
    ['Medicine', 'মেডিসিন', '💊'],
    ['Grocery', 'গ্রোসারি', '🛒']
  ];

  for (const [name, nameBn, icon] of categories) {
    await prisma.serviceCategory.upsert({
      where: { name },
      update: { nameBn, icon, isActive: true },
      create: { name, nameBn, icon, isActive: true }
    });
  }

  console.log('DISHA seed completed');
}

main().finally(async () => prisma.$disconnect());
