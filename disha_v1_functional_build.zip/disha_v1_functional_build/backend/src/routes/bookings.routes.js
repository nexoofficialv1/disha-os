const router = require('express').Router();
const { z } = require('zod');
const prisma = require('../config/db');
const { authRequired } = require('../middleware/auth');

router.post('/', authRequired, async (req, res, next) => {
  try {
    const body = z.object({
      providerId: z.number().int(),
      serviceName: z.string().trim().min(1),
      date: z.string().datetime(),
      note: z.string().optional().or(z.literal(''))
    }).parse(req.body);

    const requestedDate = new Date(body.date);
    if (requestedDate.getTime() < Date.now() - 60000) {
      return res.status(400).json({ ok: false, error: 'Past date not allowed' });
    }

    const provider = await prisma.provider.findFirst({ where: { id: body.providerId, status: 'APPROVED' } });
    if (!provider) return res.status(404).json({ ok: false, error: 'Provider not found' });

    const booking = await prisma.booking.create({
      data: {
        userId: req.user.id,
        providerId: body.providerId,
        serviceName: body.serviceName,
        date: requestedDate,
        note: body.note
      },
      include: { provider: true }
    });

    res.status(201).json({ ok: true, data: booking });
  } catch (err) { next(err); }
});

router.get('/me', authRequired, async (req, res, next) => {
  try {
    const data = await prisma.booking.findMany({
      where: { userId: req.user.id },
      include: { provider: true },
      orderBy: { createdAt: 'desc' }
    });
    res.json({ ok: true, data });
  } catch (err) { next(err); }
});

router.get('/provider', authRequired, async (req, res, next) => {
  try {
    const provider = await prisma.provider.findUnique({ where: { userId: req.user.id } });
    if (!provider) return res.json({ ok: true, data: [] });
    const data = await prisma.booking.findMany({
      where: { providerId: provider.id },
      include: { user: { select: { id: true, name: true, email: true, mobile: true } } },
      orderBy: { createdAt: 'desc' }
    });
    res.json({ ok: true, data });
  } catch (err) { next(err); }
});

router.patch('/:id/status', authRequired, async (req, res, next) => {
  try {
    const body = z.object({ status: z.enum(['ACCEPTED', 'REJECTED', 'CANCELLED', 'COMPLETED']) }).parse(req.body);
    const id = Number(req.params.id);
    const booking = await prisma.booking.findUnique({ where: { id }, include: { provider: true } });
    if (!booking) return res.status(404).json({ ok: false, error: 'Booking not found' });

    const isCustomer = booking.userId === req.user.id;
    const isProviderOwner = booking.provider.userId === req.user.id;
    if (!isCustomer && !isProviderOwner) return res.status(403).json({ ok: false, error: 'Forbidden' });
    if (body.status === 'CANCELLED' && !isCustomer) return res.status(403).json({ ok: false, error: 'Only customer can cancel' });
    if (['ACCEPTED', 'REJECTED', 'COMPLETED'].includes(body.status) && !isProviderOwner) {
      return res.status(403).json({ ok: false, error: 'Only provider can update this status' });
    }

    const updated = await prisma.booking.update({ where: { id }, data: { status: body.status } });
    res.json({ ok: true, data: updated });
  } catch (err) { next(err); }
});

module.exports = router;
