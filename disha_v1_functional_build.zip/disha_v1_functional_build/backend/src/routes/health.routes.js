const router = require('express').Router();

router.get('/', (req, res) => {
  res.json({
    ok: true,
    app: 'DISHA API',
    company: 'ASTRA Technologies',
    status: 'healthy',
    timestamp: new Date().toISOString()
  });
});

module.exports = router;
