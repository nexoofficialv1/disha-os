const router = require('express').Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { z } = require('zod');
const prisma = require('../config/db');
const { authRequired } = require('../middleware/auth');
const { safeUser } = require('../utils/safeUser');

function sign(user) {
  return jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
}

const registerSchema = z.object({
  name: z.string().trim().min(2),
  email: z.string().trim().email().optional().or(z.literal('')),
  mobile: z.string().trim().regex(/^[6-9]\d{9}$/).optional().or(z.literal('')),
  password: z.string().min(6),
  purpose: z.enum(['TAKER', 'PROVIDER', 'BOTH']).optional(),
  termsAccepted: z.boolean()
}).refine(v => Boolean(v.email || v.mobile), { message: 'Email or mobile required' });

router.post('/register', async (req, res, next) => {
  try {
    const body = registerSchema.parse(req.body);
    if (!body.termsAccepted) return res.status(400).json({ ok: false, error: 'Terms must be accepted' });

    const passwordHash = await bcrypt.hash(body.password, 12);
    const user = await prisma.user.create({
      data: {
        name: body.name,
        email: body.email || null,
        mobile: body.mobile || null,
        passwordHash,
        purpose: body.purpose,
        termsAcceptedAt: new Date()
      }
    });

    res.status(201).json({ ok: true, token: sign(user), user: safeUser(user) });
  } catch (err) { next(err); }
});

const loginSchema = z.object({
  identifier: z.string().trim().min(3),
  password: z.string().min(6)
});

router.post('/login', async (req, res, next) => {
  try {
    const body = loginSchema.parse(req.body);
    const user = await prisma.user.findFirst({
      where: {
        isActive: true,
        OR: [{ email: body.identifier }, { mobile: body.identifier }]
      }
    });
    if (!user) return res.status(401).json({ ok: false, error: 'Invalid login' });
    const valid = await bcrypt.compare(body.password, user.passwordHash);
    if (!valid) return res.status(401).json({ ok: false, error: 'Invalid login' });
    res.json({ ok: true, token: sign(user), user: safeUser(user) });
  } catch (err) { next(err); }
});

router.get('/me', authRequired, async (req, res) => {
  res.json({ ok: true, user: req.user });
});

router.patch('/purpose', authRequired, async (req, res, next) => {
  try {
    const body = z.object({ purpose: z.enum(['TAKER', 'PROVIDER', 'BOTH']) }).parse(req.body);
    const user = await prisma.user.update({ where: { id: req.user.id }, data: body });
    res.json({ ok: true, user: safeUser(user) });
  } catch (err) { next(err); }
});

router.delete('/delete-account', authRequired, async (req, res, next) => {
  try {
    await prisma.user.update({ where: { id: req.user.id }, data: { isActive: false } });
    await prisma.auditLog.create({ data: { actorId: req.user.id, action: 'ACCOUNT_DELETE_REQUESTED' } });
    res.json({ ok: true, message: 'Account deletion request accepted' });
  } catch (err) { next(err); }
});

module.exports = router;
