const router = require('express').Router();
const { z } = require('zod');
const prisma = require('../config/db');
const { authRequired } = require('../middleware/auth');

// Specific route must remain before /:providerId.
router.get('/summary', authRequired, async (req, res) => {
  res.json({ ok: true, data: { unread: 0 } });
});

router.get('/:providerId', authRequired, async (req, res, next) => {
  try {
    const providerId = Number(req.params.providerId);
    const provider = await prisma.provider.findUnique({ where: { id: providerId } });
    if (!provider) return res.status(404).json({ ok: false, error: 'Provider not found' });

    const data = await prisma.message.findMany({
      where: { providerId },
      include: { sender: { select: { id: true, name: true } } },
      orderBy: { createdAt: 'asc' }
    });
    res.json({ ok: true, data });
  } catch (err) { next(err); }
});

router.post('/:providerId', authRequired, async (req, res, next) => {
  try {
    const body = z.object({ text: z.string().trim().min(1).max(1000) }).parse(req.body);
    const providerId = Number(req.params.providerId);
    const provider = await prisma.provider.findUnique({ where: { id: providerId } });
    if (!provider) return res.status(404).json({ ok: false, error: 'Provider not found' });

    const message = await prisma.message.create({
      data: { senderId: req.user.id, providerId, text: body.text },
      include: { sender: { select: { id: true, name: true } } }
    });
    res.status(201).json({ ok: true, data: message });
  } catch (err) { next(err); }
});

module.exports = router;
