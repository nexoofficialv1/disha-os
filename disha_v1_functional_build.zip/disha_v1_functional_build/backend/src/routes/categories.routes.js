const router = require('express').Router();
const prisma = require('../config/db');

router.get('/', async (req, res, next) => {
  try {
    const data = await prisma.serviceCategory.findMany({
      where: { isActive: true },
      orderBy: [{ nameBn: 'asc' }]
    });
    res.json({ ok: true, data });
  } catch (err) { next(err); }
});

module.exports = router;
