const router = require('express').Router();

router.get('/privacy-policy', (req, res) => {
  res.json({
    ok: true,
    title: 'Privacy Policy',
    company: 'ASTRA Technologies',
    text: [
      'DISHA collects user profile, contact, provider listing, booking and chat data to provide local service discovery, communication and booking features.',
      'Location, camera, notification or file permissions are requested only when needed for the relevant app function.',
      'Final public release must use a lawyer-reviewed privacy policy hosted on the official domain.'
    ]
  });
});

router.get('/terms', (req, res) => {
  res.json({
    ok: true,
    title: 'Terms & Conditions',
    company: 'ASTRA Technologies',
    text: [
      'Users and providers must provide correct information.',
      'DISHA must not be used for fraud, spam, illegal services, harassment or impersonation.',
      'Official service integrations must be used only through authorized APIs or official portal redirects.'
    ]
  });
});

module.exports = router;
